import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import Mock

import pytest
import requests
import sys
import types

# The RSS parser is mocked in these tests; this shim permits offline test collection.
sys.modules.setdefault("feedparser", types.SimpleNamespace(parse=lambda _: None))
import main


def item(title, source="A", hours=0, summary="", link=None):
    dt = datetime.now(timezone.utc) - timedelta(hours=hours)
    return {"source": source, "region": "ru", "dt": dt, "title": title, "summary": summary,
            "link": link or f"https://example.test/{source}/{title[:8]}", "id": link or f"id-{source}-{title[:8]}",
            "tokens": main.tokens(title + " " + summary)}


def test_parse_json_with_fence_and_preface():
    assert main.parse_json('```json\n{"ok": true}\n```') == {"ok": True}
    assert main.parse_json('answer: {"skip": false, "headline": "x"}') == {"skip": False, "headline": "x"}
    assert main.parse_json("not json") is None
    assert main.parse_json('[1,2]') is None


def test_old_state_migrates(tmp_path):
    path = tmp_path / "state.json"
    path.write_text(json.dumps({"seen": ["abc"], "titles": [["новост"]], "budget": {"day": "x", "n": 2}}), encoding="utf-8")
    state = main.load_state(path)
    assert state["version"] == 2
    assert state["seen"] == ["abc"]
    assert state["titles"] == [["новост"]]
    assert state["items"] == {}


def test_corrupt_state_preserved_and_backup_restored(tmp_path):
    path = tmp_path / "state.json"
    path.write_text("{broken", encoding="utf-8")
    path.with_suffix(".json.bak").write_text(json.dumps({"seen": ["safe"]}), encoding="utf-8")
    state = main.load_state(path)
    assert state["seen"] == ["safe"]


def test_atomic_save_and_backup(tmp_path):
    path = tmp_path / "state.json"
    main.save_state({"seen": ["one"], "titles": []}, path)
    main.save_state({"seen": ["two"], "titles": []}, path)
    assert json.loads(path.read_text(encoding="utf-8"))["seen"] == ["two"]
    assert json.loads(path.with_suffix(".json.bak").read_text(encoding="utf-8"))["seen"] == ["one"]


def test_clustering_merges_similar_but_not_unrelated():
    a = item("Правительство утвердило новый закон о транспорте", "ТАСС")
    b = item("Правительство утвердило новый закон для транспорта", "РИА")
    c = item("В Самаре открылся новый спортивный комплекс", "РБК")
    clusters = main.build_clusters([a, b, c])
    assert sorted(len(c["items"]) for c in clusters) == [1, 2]
    two = next(c for c in clusters if len(c["items"]) == 2)
    assert two["n"] == 2


def test_cluster_counts_unique_sources():
    a = item("Центробанк изменил ключевую ставку", "ТАСС", link="1")
    b = item("Центробанк изменил ключевую ставку сегодня", "ТАСС", link="2")
    cluster = main.build_clusters([a, b])[0]
    assert cluster["n"] == 1


def test_parse_datetime_missing_and_valid():
    assert main.parse_datetime({}) is None
    stamp = time_tuple = datetime(2026, 1, 1, tzinfo=timezone.utc).timetuple()
    assert main.parse_datetime({"published_parsed": stamp}) == datetime(2026, 1, 1, tzinfo=timezone.utc)


def test_fetch_items_skips_missing_date(monkeypatch):
    entry = {"title": "No date", "link": "https://x.test"}
    fake = Mock()
    fake.raise_for_status.return_value = None
    fake.content = b"feed"
    monkeypatch.setattr(main, "FEEDS", [{"name": "test", "url": "https://feed.test", "region": "ru"}])
    monkeypatch.setattr(main.SESSION, "get", lambda *a, **kw: fake)
    monkeypatch.setattr(main.feedparser, "parse", lambda _: Mock(entries=[entry]))
    assert main.fetch_items() == []


def test_spend_limit(monkeypatch):
    monkeypatch.setattr(main, "DAILY_LIMIT", 1)
    state = {"budget": {"day": main.utcnow().strftime("%Y-%m-%d"), "n": 0}}
    main.spend(state)
    with pytest.raises(main.QuotaError):
        main.spend(state)


def test_failed_telegram_does_not_mark_seen(monkeypatch):
    monkeypatch.setattr(main, "DRY_RUN", False)
    response = Mock()
    response.status_code = 200
    response.json.return_value = {"ok": False, "description": "failed"}
    monkeypatch.setattr(main.SESSION, "post", lambda *a, **kw: response)
    with pytest.raises(RuntimeError):
        main.tg_send("@channel", "text")


def test_dry_run_does_not_send(monkeypatch, capsys):
    monkeypatch.setattr(main, "DRY_RUN", True)
    monkeypatch.setattr(main.SESSION, "post", lambda *a, **kw: pytest.fail("network call in dry run"))
    assert main.tg_send("@channel", "hello") is None
    assert "hello" in capsys.readouterr().out


def test_retry_after_respected():
    response = Mock()
    response.headers = {"Retry-After": "7"}
    assert main._retry_delay(response, 0) == 7.0


def test_record_status_only_terminal_states_are_seen():
    state = {"seen": [], "items": {}}
    main.record_status(state, ["a"], "pending", "telegram error")
    assert state["seen"] == []
    main.record_status(state, ["a"], "published")
    assert state["seen"] == ["a"]


def test_write_post_accepts_only_factchecked_claims(monkeypatch):
    replies = [
        {"skip": False, "headline": "Центробанк изменил ставку", "text": "Решение опубликовано сегодня."},
        {"ok": True, "problem": "", "claims": [
            {"claim": "ставка изменена", "supported": True, "evidence": "заголовок источника", "sources": ["ТАСС"]}
        ]},
    ]
    monkeypatch.setattr(main, "llm", lambda prompt, state: replies.pop(0))
    cluster = {"items": [item("Центробанк изменил ставку", "ТАСС")], "sources": ["ТАСС"]}
    assert main.write_post(cluster, {}) == {"headline": "Центробанк изменил ставку", "text": "Решение опубликовано сегодня."}


def test_write_post_rejects_unsupported_claim(monkeypatch):
    replies = [
        {"skip": False, "headline": "Центробанк изменил ставку", "text": "Из-за инфляции."},
        {"ok": False, "problem": "причина не подтверждена", "claims": [
            {"claim": "из-за инфляции", "supported": False, "evidence": "", "sources": []}
        ]},
    ]
    monkeypatch.setattr(main, "llm", lambda prompt, state: replies.pop(0))
    cluster = {"items": [item("Центробанк изменил ставку", "ТАСС")], "sources": ["ТАСС"]}
    assert main.write_post(cluster, {}) is None


def test_failed_telegram_http_does_not_claim_success(monkeypatch):
    monkeypatch.setattr(main, "DRY_RUN", False)
    response = Mock()
    response.status_code = 500
    response.json.return_value = {"ok": False, "description": "temporary failure"}
    response.raise_for_status.side_effect = requests.HTTPError("500")
    monkeypatch.setattr(main.SESSION, "post", lambda *a, **kw: response)
    with pytest.raises(requests.HTTPError):
        main.tg_send("@channel", "text")
